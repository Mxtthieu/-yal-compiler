package yal.exceptions;

public abstract class AnalyseException extends RuntimeException {
    
    protected AnalyseException(String m) {
        super(m) ;
    }

}
